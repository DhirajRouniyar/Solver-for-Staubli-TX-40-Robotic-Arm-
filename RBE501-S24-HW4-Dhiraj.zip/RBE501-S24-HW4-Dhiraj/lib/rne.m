function [tau,V,Vdot] = rne(params)
%% RNE Implements the Recursive Newton-Euler Inverse Dynamics Algorithm
%
% Inputs: params - a structure containing the following fields:
%           params.g - 3-dimensional column vector describing the acceleration of gravity
%           params.S - 6xn matrix of screw axes (each column is an axis)
%           params.M - 4x4xn home configuration matrix for each link
%           params.G - 6x6xn spatial inertia matrix for each link
%           params.jointPos - n-dimensional column vector of joint coordinates
%           params.jointVel - n-dimensional column vector of joint velocities
%           params.jointAcc - n-dimensional column vector of joint accelerations
%           params.Ftip - 6-dimensional column vector representing the
%           wrench applied at the tip
%
% Output: tau  - n-dimensional column vector of generalized joint forces
%         V    - 6x(n+1) matrix - each column represents the twist of one of the robot's links
%         Vdot - 6x(n+1) matrix - each column represents the acceleration of one of the robot's links
%
% Forward iterations
% YOUR CODE HERE 
V         = zeros(6, length(params.jointPos)+1)
Vdot      = zeros(6, length(params.jointPos)+1)
% Vdot(:,1) = [zeros(3,1); -params.g']
Vdot(:,1) = [0 0 0 -params.g'];

M_i = params.M

for i=1:length(params.jointPos)
    M_i(:,:,i+1) = M_i(:,:,i)*params.M(:,:,i+1)
    A(:,i)       = adjoint(inv(M_i(:,:,i)))*params.S(:,i);
    T(:,:,i)     = params.M(:,:,i)*twist2ht(A(:,i),params.jointPos(i));
    V(:,i+1)     = A(:,i)*params.jointVel(i) + adjoint(inv(T(:,:,i)))*V(:,i)
    Vdot(:,i+1)  = A(:,i)*params.jointAcc(i) + adjoint(inv(T(:,:,i)))*Vdot(:,i) + ad(V(:,i+1))*A(:,i)*params.jointVel(i)
end
% Backward iterations
% YOUR CODE HERE
F_adv       = params.Ftip;
tau         = zeros(length(params.jointPos),1);
T(:,:,length(params.jointPos)+1) =  params.M(:,:,length(params.jointPos)+1)

for i      = length(params.jointPos):-1:1
    F      = params.G(:,:,i)*Vdot(:,i+1) - transpose(ad(V(:,i+1)))*params.G(:,:,i)*V(:,i+1) + transpose(adjoint(inv(T(:,:,i+1))))*F_adv;
    tau(i) = F'*A(:,i); 
    F_adv  = F;

end

end
function AdT = adjoint(T)
    % your code here
    
    skew     = @(x) [0 -x(3) x(2); x(3) 0 -x(1); -x(2) x(1) 0];
    
    p = T(1:3,4);
    R = T(1:3,1:3);
    
    AdT      = [R zeros(3,3); skew(p)*R R];
end

function adV = ad(V)
    % your code here
    omega    = V(1:3);
    v        = V(4:6);
    skew     = @(x) [0 -x(3) x(2); x(3) 0 -x(1); -x(2) x(1) 0];
    
    adV      = [skew(omega) zeros(3,3); skew(v) skew(omega)];
end

function T = twist2ht(S,theta)
    % your code here
    
    % If needed, you can calculate a rotation matrix with:
    % R = axisangle2rot(omega,theta);
    skew  = @(x) [0 -x(3) x(2); x(3) 0 -x(1); -x(2) x(1) 0];
    v     = S(4:6);
    omega = S(1:3);
    T(1:3, 1:3) = axisangle2rot(omega,theta);
    T(1:3, 4)   = (eye(3)*theta + (1-cos(theta))*skew(omega) + (theta - sin(theta))*skew(omega)^2)*v;
    T(4,1:3)    = 0;
    T(4,4)      = 1;

end

function R = axisangle2rot(omega,theta)
    % your code here
    skew   = @(x) [0 -x(3) x(2); x(3) 0 -x(1); -x(2) x(1) 0];
    
    % omega_skew = [0 -omega(3) omega(2); omega(3) 0 -omega(1); -omega(2) omega(1) 0];
    R            = eye(3) + sin(theta)*skew(omega) + (1 - cos(theta))*skew(omega)^2;

end