

function R = axisangle2rot(omega,theta)

% Axis angle to Rotation Conversion

% Takes omega and angle theta

% Returns the corresponding Rotation matrix

    K = [0, -omega(3), omega(2);

         omega(3), 0, -omega(1);

         -omega(2), omega(1), 0];

    

    % Compute sine and cosine of theta
    sin_theta = sin(theta);
    cos_theta = cos(theta);
    % Compute rotation matrix using Rodrigues' rotation formula

    R = eye(3) + sin_theta * K + (1 - cos_theta) * (K^2);

end