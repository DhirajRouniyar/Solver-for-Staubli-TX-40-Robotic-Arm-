% RBE 501 - Robot Dynamics - Spring 2024
% Midterm Exam
% Worcester Polytechnic Institute
%
% Instructor: L. Fichera <lfichera@wpi.edu>
% Last modified: 02/26/2024
clear, clc, close all
addpath('utils');

%% First, execute poe() to load the S and M matrices
n = 6; % number of degrees of freedom
robot = make_robot();
[S,M] = poe();
close all

robot.plot(zeros(1,n)), hold on;

%% Load the Path that the robot has to trace
load ik_data.mat
scatter3(path(1,:), path(2,:), path(3,:), 'filled');
%targetPose = zeros(6,size(path,2));
%% Solution
% [YOUR CODE HERE]



%% Calculate the inverse kinematics
plotOn = false;
currentPose = MatrixLog6(M);
disp(currentPose)
currentPose = [currentPose(3,2) currentPose(1,3) currentPose(2,1) currentPose(1:3,4)']';
currentQ = zeros(1,6);
robot.teach(currentQ);
for ii = 1 : size(path,2)
    while norm(targetPose(:,ii) - currentPose) > 1e-3
        J = jacob0(S,currentQ);
           lamda =0.1;
           % deltaQ = (J'*pinv(J*J' + lamda*eye(6)))*(targetPose(:,ii) - currentPose);
           deltaQ = LevenbergMarquardtIK(J, 0.1, targetPose(:, ii), currentPose)
           currentQ = currentQ + deltaQ';
        T = fkine(S,M,currentQ);
        currentPose = MatrixLog6(T);
        currentPose = [currentPose(3,2) ...
                       currentPose(1,3) ...
                       currentPose(2,1) ...
                       currentPose(1:3,4)']';


    end
    qList(ii,:) = currentQ;
end

robot.plot(repmat([qList; flip(qList)], 10, 1), ...
    'trail', {'r', 'LineWidth', 5});