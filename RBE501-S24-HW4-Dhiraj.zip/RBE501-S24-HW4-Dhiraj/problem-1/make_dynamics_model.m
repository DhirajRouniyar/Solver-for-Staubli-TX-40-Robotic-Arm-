function [Mlist,Glist] = make_dynamics_model()
% MAKE_KINEMATICS_MODEL Creates the dynamics model of the robot
%
% Inputs: None
%
% Output: Mlist - 4x4x7 matrix containing all the transformation matrices between consecutive link frames
%         Glist - 6x6x6 matrix containing the spatial inertia matrices of each link


%% Create the manipulator
L1 = 0.3; % Lenght of Link 1 [m]
L2 = 0.3; % Lenght of Link 2 [m]
L3 = 0.15; % Lenght of Link 3 [m]
w  = 0.04; % Link Width [m]
l  = 0.04; % Link Depth [m]


M01 = [eye(3) [0 0 L1/2]'; 0 0 0 1];
M12 = [[1 0 0; 0 0 1; 0 -1 0], [0 L2/2 L1/2]'; 0 0 0 1];
M23 = [[1 0 0; 0 0 1; 0 -1 0], [0 L3/2 L2/2]'; 0 0 0 1];
M34 = [[0 1 0; 0 0 1; 1 0 0], [0 0 L3/2]'; 0 0 0 1];

Mlist = cat(3, M01, M12, M23, M34);

%% *** NOW LET US DEFINE THE INERTIAL PROPERTIES ***
m1 = 5;   % Mass of Link 1 [kg]
m2 = 1;   % Mass of Link 2 [kg]
m3 = 1;   % Mass of Link 3 [kg]
w  = 0.04; % Link Width [m]
l  = 0.04; % Link Depth [m]

% Spatial Inertia Matrices
G1 = zeros(6,6); 
Ixx1 = m1*(w^2+L1^2)/12;
Iyy1 = m1*(l^2+L1^2)/12;
Izz1 = m1*(l^2+w^2)/12;
G1(1:3,1:3) = diag([Ixx1 Iyy1 Izz1]);
G1(4:6,4:6) = m1 * eye(3);

G2 = zeros(6,6);
Ixx2 = m2*(w^2+L2^2)/12;
Iyy2 = m2*(l^2+L2^2)/12;
Izz2 = m2*(l^2+w^2)/12;
G2(1:3,1:3) = diag([Ixx2 Iyy2 Izz2]);
G2(4:6,4:6) = m2 * eye(3);

G3 = zeros(6,6);
Ixx3 = m2*(w^2+L3^2)/12;
Iyy3 = m2*(l^2+L3^2)/12;
Izz3 = m2*(l^2+w^2)/12;
G3(1:3,1:3) = diag([Ixx3 Iyy3 Izz3]);
G3(4:6,4:6) = m3 * eye(3);

Glist = cat(3, G1, G2, G3);

end